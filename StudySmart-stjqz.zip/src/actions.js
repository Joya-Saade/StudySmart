import { HttpError } from 'wasp/server'

export const processText = async ({ uploadId, text }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const upload = await context.entities.Upload.findUnique({
    where: { id: uploadId }
  });
  if (!upload || upload.userId !== context.user.id) { throw new HttpError(403) };

  // Call AI API to process text
  const aiResponse = await callAIAPI(text);
  const { summaries, flashcards, mcqs } = aiResponse;

  // Store summaries
  for (const content of summaries) {
    await context.entities.Summary.create({
      data: { content, uploadId }
    });
  }

  // Store flashcards
  for (const { question, answer } of flashcards) {
    await context.entities.Flashcard.create({
      data: { question, answer, uploadId }
    });
  }

  // Store MCQs
  for (const { question, options, correctAnswer } of mcqs) {
    await context.entities.MCQ.create({
      data: { question, options: JSON.stringify(options), correctAnswer, uploadId }
    });
  }

  return { success: true };
}

export const exportContent = async ({ contentType, uploadId }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const upload = await context.entities.Upload.findUnique({
    where: { id: uploadId },
    include: {
      summaries: contentType === 'summary',
      flashcards: contentType === 'flashcard',
      mcqs: contentType === 'mcq'
    }
  });

  if (!upload) { throw new HttpError(404, 'Upload not found') };
  if (upload.userId !== context.user.id) { throw new HttpError(403) };

  let content;
  switch (contentType) {
    case 'summary':
      content = upload.summaries;
      break;
    case 'flashcard':
      content = upload.flashcards;
      break;
    case 'mcq':
      content = upload.mcqs;
      break;
    default:
      throw new HttpError(400, 'Invalid content type');
  }

  // Export logic would go here, e.g., converting content to PDF/CSV format.
  // For now, just return the content as a placeholder.
  return content;
}
