import { HttpError } from 'wasp/server'

export const getUserUploads = async (args, context) => {
  if (!context.user) { throw new HttpError(401); }

  return await context.entities.Upload.findMany({
    where: { userId: context.user.id },
    include: {
      summaries: true,
      flashcards: true,
      mcqs: true
    }
  });
}

export const getUploadDetails = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const upload = await context.entities.Upload.findUnique({
    where: { id },
    include: {
      summaries: true,
      flashcards: true,
      mcqs: true
    }
  });

  if (!upload) throw new HttpError(404, 'No upload with id ' + id);

  return upload;
}
