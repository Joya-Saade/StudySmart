import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getUserUploads } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const HistoryPage = () => {
  const { data: uploads, isLoading, error } = useQuery(getUserUploads);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Upload History</h1>
      {uploads.map(upload => (
        <div key={upload.id} className="mb-4 p-4 border rounded-lg bg-white shadow">
          <p className="font-semibold">Upload ID: {upload.id}</p>
          <p>Created At: {new Date(upload.createdAt).toLocaleString()}</p>
          <h2 className="mt-2 text-xl">Summaries</h2>
          <ul className="list-disc list-inside">
            {upload.summaries.map(summary => (
              <li key={summary.id}>{summary.content}</li>
            ))}
          </ul>
          <h2 className="mt-2 text-xl">Flashcards</h2>
          <ul className="list-disc list-inside">
            {upload.flashcards.map(flashcard => (
              <li key={flashcard.id}>{flashcard.question} - {flashcard.answer}</li>
            ))}
          </ul>
          <h2 className="mt-2 text-xl">MCQs</h2>
          <ul className="list-disc list-inside">
            {upload.mcqs.map(mcq => (
              <li key={mcq.id}>{mcq.question} - Options: {JSON.parse(mcq.options).join(', ')} - Correct Answer: {mcq.correctAnswer}</li>
            ))}
          </ul>
          <Link to={`/upload/${upload.id}`} className="text-blue-500 hover:underline mt-2 block">View Details</Link>
        </div>
      ))}
    </div>
  );
};

export default HistoryPage;
