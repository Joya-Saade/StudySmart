import React, { useState } from 'react';
import { useQuery, useAction, getUserUploads, processText } from 'wasp/client/operations';
import { Tab } from '@headlessui/react';

const DashboardPage = () => {
  const { data: uploads, isLoading, error } = useQuery(getUserUploads);
  const processTextFn = useAction(processText);
  const [textInput, setTextInput] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const handleProcessText = () => {
    if (textInput) {
      processTextFn({ text: textInput, uploadId: selectedFile ? selectedFile.id : null });
      setTextInput('');
    }
  };

  return (
    <div className="p-4">
      <div className="flex gap-x-4 py-5">
        <textarea
          placeholder="Paste your text here"
          className="w-full px-2 py-2 border rounded text-lg"
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
        />
        <button
          onClick={handleProcessText}
          className="bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded"
        >
          Process Text
        </button>
      </div>
      <div className="flex py-5">
        <input
          type="file"
          onChange={handleFileChange}
          className="px-1 py-2 border rounded text-lg"
        />
      </div>
      <Tab.Group>
        <Tab.List className="flex space-x-1 bg-blue-900/20 p-1">
          <Tab
            className={({ selected }) =>
              selected
                ? 'bg-white shadow text-blue-700'
                : 'text-blue-100 hover:bg-white/[0.12] hover:text-white'
            }
            className="w-full py-2.5 text-sm leading-5 font-medium text-blue-700 rounded-lg"
          >
            Summaries
          </Tab>
          <Tab
            className={({ selected }) =>
              selected
                ? 'bg-white shadow text-blue-700'
                : 'text-blue-100 hover:bg-white/[0.12] hover:text-white'
            }
            className="w-full py-2.5 text-sm leading-5 font-medium text-blue-700 rounded-lg"
          >
            Flashcards
          </Tab>
          <Tab
            className={({ selected }) =>
              selected
                ? 'bg-white shadow text-blue-700'
                : 'text-blue-100 hover:bg-white/[0.12] hover:text-white'
            }
            className="w-full py-2.5 text-sm leading-5 font-medium text-blue-700 rounded-lg"
          >
            MCQs
          </Tab>
        </Tab.List>
        <Tab.Panels>
          <Tab.Panel>
            <div className="p-4">
              {uploads.map(upload => upload.summaries.map(summary => (
                <div key={summary.id} className="border-b border-gray-200 py-2">
                  {summary.content}
                </div>
              )))}
            </div>
          </Tab.Panel>
          <Tab.Panel>
            <div className="p-4">
              {uploads.map(upload => upload.flashcards.map(flashcard => (
                <div key={flashcard.id} className="border-b border-gray-200 py-2">
                  <strong>Q:</strong> {flashcard.question} <br />
                  <strong>A:</strong> {flashcard.answer}
                </div>
              )))}
            </div>
          </Tab.Panel>
          <Tab.Panel>
            <div className="p-4">
              {uploads.map(upload => upload.mcqs.map(mcq => (
                <div key={mcq.id} className="border-b border-gray-200 py-2">
                  <strong>Q:</strong> {mcq.question} <br />
                  <strong>Options:</strong> {JSON.parse(mcq.options).join(', ')} <br />
                  <strong>Correct Answer:</strong> {mcq.correctAnswer}
                </div>
              )))}
            </div>
          </Tab.Panel>
        </Tab.Panels>
      </Tab.Group>
    </div>
  );
};

export default DashboardPage;
