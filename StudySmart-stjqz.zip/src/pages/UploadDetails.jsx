import React from 'react';
import { useParams } from 'wasp/client/router';
import { useQuery, useAction, getUploadDetails, exportContent } from 'wasp/client/operations';

const UploadDetailsPage = () => {
  const { uploadId } = useParams();
  const { data: uploadDetails, isLoading, error } = useQuery(getUploadDetails, { id: uploadId });
  const exportContentFn = useAction(exportContent);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleExport = async (contentType) => {
    try {
      const content = await exportContentFn({ contentType, uploadId });
      // Implement download logic here
      console.log('Exported content:', content);
    } catch (err) {
      console.error('Export failed:', err);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Upload Details</h1>

      <div className="mb-6">
        <h2 className="text-xl font-semibold">Summaries</h2>
        <ul className="list-disc pl-5">
          {uploadDetails.summaries.map((summary) => (
            <li key={summary.id}>{summary.content}</li>
          ))}
        </ul>
        <button
          onClick={() => handleExport('summary')}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2"
        >
          Export Summaries
        </button>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-semibold">Flashcards</h2>
        <ul className="list-disc pl-5">
          {uploadDetails.flashcards.map((flashcard) => (
            <li key={flashcard.id}>{flashcard.question} - {flashcard.answer}</li>
          ))}
        </ul>
        <button
          onClick={() => handleExport('flashcard')}
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-2"
        >
          Export Flashcards
        </button>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-semibold">MCQs</h2>
        <ul className="list-disc pl-5">
          {uploadDetails.mcqs.map((mcq) => (
            <li key={mcq.id}>{mcq.question} - Options: {mcq.options.join(', ')}</li>
          ))}
        </ul>
        <button
          onClick={() => handleExport('mcq')}
          className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded mt-2"
        >
          Export MCQs
        </button>
      </div>
    </div>
  );
};

export default UploadDetailsPage;
